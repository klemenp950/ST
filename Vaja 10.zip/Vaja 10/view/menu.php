<p>[
<a href="<?= BASE_URL . "book" ?>">All books</a> |
<a href="<?= BASE_URL . "book/search" ?>">Search</a> | 
<a href="<?= BASE_URL . "book/add" ?>">Add new</a> |
<a href="<?= BASE_URL . "store" ?>">Bookstore</a> |
<a href="<?= BASE_URL . "ajax/store" ?>">AJAX Bookstore</a> |
<a href="<?= BASE_URL . "book/search-ajax" ?>">AJAX Search</a> |
<a href="<?= BASE_URL . "book/search-vue" ?>">Vue Search</a>
]</p>